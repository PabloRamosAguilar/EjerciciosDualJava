package alumno;



public interface IVendible {
public void vender(int cantidad);
public boolean hayStock(int num);
}
