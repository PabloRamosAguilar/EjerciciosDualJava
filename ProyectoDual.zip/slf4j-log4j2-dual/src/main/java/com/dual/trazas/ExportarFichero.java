package com.dual.trazas;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExportarFichero {
	private static final Logger LOGGERFILE = LoggerFactory.getLogger(ExportarFichero.class);

	public void crearFichero(String pi) {
		LOGGERFILE.info("ENTRAMOS EN CREAR FICHERO");
		String file = "guardardatosdePI/calculo.txt";
		String separador = ";";
		String[][] datos = { { pi }

		};
		try {
			LOGGERFILE.debug("VAMOS A ENTRAR EN exportarCsv()");
			UtilidadesCsv utilCsv = new UtilidadesCsv();
			utilCsv.exportarCsv(datos, file, separador);

			LOGGERFILE.debug("FIN DE LA ESCRITURA");
		} catch (Exception ioe) {
			ioe.printStackTrace();
			LOGGERFILE.error("HA OCURRIDO UN ERROR DEL TIPO I/O --> {} ", ioe.getMessage());
		} finally {
			LOGGERFILE.info("SALIMOS DE CREAR FICHERO");
		}
	}
}
