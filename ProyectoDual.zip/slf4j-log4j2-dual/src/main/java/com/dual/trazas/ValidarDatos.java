package com.dual.trazas;

import java.util.InputMismatchException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ValidarDatos {
	private static final Logger LOGGEROP = LoggerFactory.getLogger(ValidarDatos.class);

	public boolean guardarDatos(String controlador) {
		LOGGEROP.info("ENTRAMOS EN GUARDAR DATOS");
		boolean resultado = true;

		try {
			validarDatos(controlador);

		} catch (NullPointerException ne) {
			ne.printStackTrace();
			LOGGEROP.error("SE HA DADO UNA EXCEPCION INPUT MISMATCH EXCEPTION --> {}", ne.getMessage());
			resultado = false;
		} catch (InputMismatchException ie) {
			ie.printStackTrace();
			LOGGEROP.error("SE HA DADO UNA EXCEPCION INPUT MISMATCH EXCEPTION --> {}", ie.getMessage());
			resultado = false;
		} catch (Exception e) {
			e.printStackTrace();
			LOGGEROP.error("SE HA DADO UNA EXCEPCION GEN�RICA --> {}", e.getMessage());
			resultado = false;
		} catch (Throwable te) {
			te.printStackTrace();
			LOGGEROP.error("SE HA DADO UN THROWABLE --> {}", te.getMessage());
			resultado = false;
		} finally {
			LOGGEROP.info("SALIMOS DE GUARDAR DATOS CON RESULTADO: --> {}", resultado);
		}
		return resultado;
	}

	public void validarDatos(String controlador) throws Exception, InputMismatchException, NullPointerException {
		LOGGEROP.info("ENTRAMOS EN VALIDAR DATOS");
		if (controlador == null) {
			LOGGEROP.error("EL VALOR ES NULO");
			throw new NullPointerException("El formato del nombre no es valido, es un valor nulo.");
		}
		if (controlador.matches("[a-zA-Z]+")||("".equals(controlador.trim()))) {
			LOGGEROP.error("EL NOMBRE CONFORMA LA EXPRESION REGULAR [a-zA-Z]+ O ES UNA CADENA VACIA");
			throw new InputMismatchException(
					"El formato del nombre no es valido, se han introducido car�cteres prohibidos.");
		}

		LOGGEROP.info("SALIMOS DE VALIDAR DATOS");
	}
}
