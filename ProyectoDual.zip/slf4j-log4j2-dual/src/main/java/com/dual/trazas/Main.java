package com.dual.trazas;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Main {

	private static final Logger LOGGERMAIN = LoggerFactory.getLogger(Main.class);

	public static void main(String[] args) {
		LOGGERMAIN.info("ENTRAMOS EN MAIN");
		Scanner input = new Scanner(System.in);
		ValidarDatos op = new ValidarDatos();
		ExportarFichero exportar = new ExportarFichero();

		String controladorExcepcionInputMismatch = "";

		System.out.print("Inserta el n�mero de iteraciones a realizar: ");
		controladorExcepcionInputMismatch = input.nextLine();
		LOGGERMAIN.debug("VAMOS A INVOCAR A GUARDAR DATOS()");
		boolean resultado = op.guardarDatos(controladorExcepcionInputMismatch);
		LOGGERMAIN.trace("VAMOS A ENTRAR EN TRY-MAIN");
		try {
			if (resultado) {
				int iteraciones = Integer.parseInt(controladorExcepcionInputMismatch);
				LOGGERMAIN.debug("VAMOS A INVOCAR A CalcPi()");
				Double aproximacionPi = CalcPi.calcPi(iteraciones);
				LOGGERMAIN.debug("VAMOS A INVOCAR A CrearFichero()");
				exportar.crearFichero(aproximacionPi.toString());
			}
			if (!resultado) {
				throw new Exception("Existe un problema con la variable introducida.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOGGERMAIN.error("RESULTADO ES FALSO --> {}", e.getMessage());
		} finally {
			input.close();
			LOGGERMAIN.info("SALIMOS DE MAIN");
		}
	}

}
