package com.dual.trazas;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CalcPi {
	private static final Logger LOGGERCALC = LoggerFactory.getLogger(CalcPi.class);

	public static double calcPi(final int iterations) {
		LOGGERCALC.info("ENTRAMOS EN calcPi()");

		double pi = 0;
		double y = 1;

		int lps = iterations * 2;
		int cnt = 0;
		LOGGERCALC.debug("VAMOS A CALCULAR EL VALOR DE PI CON {} ITERACIONES", iterations);
		for (int x = 1; x < lps; x += 2) {
			pi = pi + (y / x);
			y = -y;
			cnt++;
		LOGGERCALC.trace("El valor de PI en la iteracion {} es {} ", iterations, 4*pi);
		}
		LOGGERCALC.info("SALIMOS DE calcPi() CON RESULTADO --> {}", 4*pi);
		return 4 * pi;
	}

}
