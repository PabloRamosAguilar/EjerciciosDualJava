package com.dual.trazas;

import java.io.FileWriter;
import java.io.PrintWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class UtilidadesCsv {
	private static final Logger LOGGERCSV = LoggerFactory.getLogger(UtilidadesCsv.class);

	public void exportarCsv(String[][] datos, String file, String separador) {
		LOGGERCSV.info("ENTRAMOS EN exportarCsv");

		try {
			FileWriter writer = new FileWriter(file);
			PrintWriter printer = new PrintWriter(file);
			StringBuilder linea = new StringBuilder();

			for (int i = 0; i < datos.length; i++) {

				LOGGERCSV.trace("El valor de linea en esta iteracion es {} ", linea);

				for (int j = 0; j < datos[i].length; j++) {
					linea.append(datos[i][j] + separador);
				}
				linea.append("\n");
			}
			LOGGERCSV.debug("SE VA A ESCRIBIR LINEA EN EL ARCHIVO");
			printer.write(linea.toString());

			writer.close();
			printer.close();

			LOGGERCSV.trace("SE HAN CERRADO WRITER Y PRINTER");

		} catch (IOException e) {
			e.printStackTrace();
			LOGGERCSV.error("HA OCURRIDO UN ERROR DEL TIPO I/O --> {}", e.getMessage());
		} finally {

			LOGGERCSV.info("SALIMOS DE exportarCsv");

		}
	}
}
